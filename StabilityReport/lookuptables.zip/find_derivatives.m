%post process

%Put in names of the data files
filenames = {'f1f2_0.txt','f1_-20.txt', 'f1_+20.txt','f1_+30.txt',...
                          'f2_-20.txt', 'f2_+20.txt','f2_+30.txt',...
             'f1f2_20.txt' , ...
             'a1_+20.txt', 'a2_+20.txt','a1a2_+20.txt',...             
              'beta_4.txt', 'beta_8.txt'    };
colors = {'bx','rx','ro','r+','kx','ko','k+','gx'};
%And the associated surface control variables
d_f1 = [0, -20, +20, + 30, 0 ,  0,  0, +20, 0  ,  0 , 0 , 0, 0]; %inner flap
d_f2 = [0, 0  ,   0,    0,-20,+20,+30, +20, 0  ,  0 , 0 , 0, 0]; %outter flap
d_a1 = [0, 0  ,   0,    0,  0,  0,  0,   0, +20,  0 ,+20, 0, 0]; %inner ailevon
d_a2 = [0, 0  ,   0,    0,  0,  0,  0,   0, 0  , +20,+20, 0, 0]; %outter ailevon
beta = [0, 0  ,   0,    0,  0,  0,  0,   0, 0  , 0  ,  0, -4, -8]; %sideslip


%Parse in the data
nlon = 1:8;
nlat = [1,9:13];
for i = 1:13
    
   Configurations(i).d_con = ...
       deg2rad([(d_f1(i)), (d_f2(i)), (d_a1(i)), (d_a2(i)), (beta(i))]);
   
   polar = importdata(filenames{i},' ', 9); %skipping first 9 lines
   Configurations(i).alpha = deg2rad(polar.data(:,1)); %AoA
   Configurations(i).CL    = polar.data(:,2); %Lift coefficient
   Configurations(i).CD    = polar.data(:,5); %Drag coefficient   
   Configurations(i).CY    = polar.data(:,6); %Side force
   Configurations(i).CM    = polar.data(:,7); %Pitching moment
   Configurations(i).RM    = polar.data(:,8); %Rolling moment
   Configurations(i).YM    = polar.data(:,9); %Yawing moment
end


%%
%Let's find longitudinal derivatives using least squares
CL_vec = []; CM_vec = []; CD_vec = [];
m = 0;
A = []; A_cd = [];
for i = nlon
   mi = length(Configurations(i).alpha);
   CL_vec = [CL_vec ; Configurations(i).CL];
   CM_vec = [CM_vec ; Configurations(i).CM];
   CD_vec = [CD_vec ; Configurations(i).CD];
   % Cl0 * 1    +    CL_alpha * alpha   + CL_df1 * d_f1 + .....
   % Cm0* 1     + Cm_alpha * alpha + Cm_df1 * d_f1 + ...
   A = [A ; [ones(mi,1), Configurations(i).alpha, ...
       repmat(Configurations(i).d_con(1:5),mi,1)]];
   
   % CD_0 + CD_CL1 * CL + CD_CL2 * CL^2 + CD_df1*df1^2
   A_cd = [A_cd; [ones(mi,1), Configurations(i).CL, ...
       Configurations(i).CL.^2, ...
       repmat(Configurations(i).d_con(1:2),mi,1).^2]];
   m = m + mi;
end

%least squares
CLCM_der = pinv(A)*[CL_vec, CM_vec];
CD_der = pinv(A_cd) * CD_vec;

%Extracting the derivatives
CL_0 = CLCM_der(1,1);
CL_alpha = CLCM_der(2,1);
CL_df1   = CLCM_der(3,1);
CL_df2   = CLCM_der(4,1);

CM_0 = CLCM_der(1,2);
CM_alpha = CLCM_der(2,2);
CM_df1   = CLCM_der(3,2);
CM_df2   = CLCM_der(4,2);

CD_0 = CD_der(1);
CD_CL1 = CD_der(2);
CD_CL2 = CD_der(3);
CD_df1 = CD_der(4);
CD_df2 = CD_der(5);

fprintf('CL_0= %f , CL_alpha = %f, CL_df1=%f, CL_df2=%f\n',...
    CL_0,CL_alpha,CL_df1,CL_df2);
fprintf('CM_0= %f , CM_alpha = %f, CM_df1=%f, CM_df2=%f\n',...
    CM_0,CM_alpha,CM_df1,CM_df2);
fprintf('CD_0= %f , CD_CL1 = %f, CD_CL21=%f, CD_df1=%f, CD_df2=%f\n',...
    CD_0,CD_CL1,CD_CL2,CD_df1,CD_df2);



%%
%Let's find the lateral derivatives
CY_vec = []; RM_vec = []; YM_vec = [];
m = 0;
A = []; 
for i = nlat
   mi = length(Configurations(i).alpha);
   CY_vec = [CY_vec ; Configurations(i).CY];
   RM_vec = [RM_vec ; Configurations(i).RM];
   YM_vec = [YM_vec ; Configurations(i).YM];
   %        CY_0*1 + CY_alpha*alpha + CY_da1*d_a1 + CY_da2*d_a2+ CY_beta*beta 
   %        RM_0*1 + RM_alpha*alpha + RM_da1*d_a1 + RM_da2*d_a2+ RM_beta*beta 
   %        YM_0*1 + YM_alpha*alpha + YM_da1*d_a1 + YM_da2*d_a2+ YM_beta*beta 
   A = [A ; [ones(mi,1), repmat(Configurations(i).d_con(3:5),mi,1) ...
                        ,Configurations(i).alpha]];

   m = m + mi;
end

%Least-squares
CYRMYM_der = pinv(A)*[CY_vec, RM_vec, YM_vec];
%Extracting the right derivatives ...
CY_0 = CYRMYM_der(1,1);
CY_da1   = CYRMYM_der(2,1);
CY_da2   = CYRMYM_der(3,1);
CY_beta   = CYRMYM_der(4,1);
CY_alpha = CYRMYM_der(5,1);

RM_0 = CYRMYM_der(1,2);
RM_da1   = CYRMYM_der(2,2);
RM_da2   = CYRMYM_der(3,2);
RM_beta   = CYRMYM_der(4,2);
RM_alpha = CYRMYM_der(5,2);

YM_0 = CYRMYM_der(1,3);
YM_da1   = CYRMYM_der(2,3);
YM_da2   = CYRMYM_der(3,3);
YM_beta   = CYRMYM_der(4,3);
YM_alpha = CYRMYM_der(5,3);

fprintf('CY_0= %f , CY_beta = %f,CY_alpha=%f, CY_da1=%f, CY_da2=%f\n',...
    CY_0,CY_beta,CY_alpha,CY_da1,CY_da2);
fprintf('RM_0= %f , RM_beta = %f,RM_alpha=%f, RM_da1=%f, RM_da2=%f\n',...
    RM_0,RM_beta,RM_alpha,RM_da1,RM_da2);
fprintf('YM_0= %f , YM_beta = %f,YM_alpha=%f, YM_da1=%f, YM_da2=%f\n',...
    YM_0,YM_beta,YM_alpha,YM_da1,YM_da2);

%%
%Plotting for good measure ...
colors = {'b','r','r','r','k','k','k','g'};

figure(); hold on;
for k = nlon
plot(Configurations(k).alpha,Configurations(k).CL,'b');
plot(Configurations(k).alpha,CL_0 + CL_alpha * Configurations(k).alpha ...
                           + CL_df1 * Configurations(k).d_con(1)...
                           + CL_df2 * Configurations(k).d_con(2),...
                           [colors{k},'x']);
end
xlabel('alpha(rad)'); ylabel('CL'); title('Lift Coefficient');

%%

figure(); hold on;
for k = nlon
plot(Configurations(k).alpha,Configurations(k).CM,'b');
plot(Configurations(k).alpha,CM_0 + CM_alpha * Configurations(k).alpha ...
                           + CM_df1 * Configurations(k).d_con(1)...
                           + CM_df2 * Configurations(k).d_con(2),...
                           [colors{k},'x']);
end
xlabel('alpha(rad)'); ylabel('CM'); title('CM Coefficient');

%%

figure(); hold on;
for k = nlon
plot(Configurations(k).CL,Configurations(k).CD,[colors{k},'--']);
plot(Configurations(k).CL,CD_0 + CD_CL1 * Configurations(k).CL ...
                           + CD_CL2 * Configurations(k).CL.^2 ...
                           + CD_df1 * Configurations(k).d_con(1)^2 ...
                           + CD_df2 * Configurations(k).d_con(2)^2,...
                           [colors{k},'x']);
end
xlabel('CL'); ylabel('CD')



%%
%Lateral derivatives
figure(); hold on;
for k = nlat
plot(Configurations(k).alpha,Configurations(k).CY,'b');
plot(Configurations(k).alpha,CY_0 + CY_beta * Configurations(k).d_con(5) ...
                           + CY_da1 * Configurations(k).d_con(3)...
                           + CY_da2 * Configurations(k).d_con(4)...
                           + CY_alpha * Configurations(k).alpha ,'rx');
end
xlabel('alpha'); ylabel('CY');

%%

figure(); hold on;
for k = nlat
plot(Configurations(k).alpha,Configurations(k).RM,'b');
plot(Configurations(k).alpha,RM_0 + RM_beta * Configurations(k).d_con(5) ...
                           + RM_da1 * Configurations(k).d_con(3)...
                           + RM_da2 * Configurations(k).d_con(4)...
                           + RM_alpha * Configurations(k).alpha ,'r--');
end
xlabel('alpha'); ylabel('RM');

%%
figure(); hold on;
for k = nlat
plot(Configurations(k).alpha,Configurations(k).YM,'b');
plot(Configurations(k).alpha,YM_0 + YM_beta * Configurations(k).d_con(5) ...
                           + YM_da1 * Configurations(k).d_con(3)...
                           + YM_da2 * Configurations(k).d_con(4)...
                           + YM_alpha * Configurations(k).alpha ,'r--');
end
xlabel('alpha'); ylabel('YM');